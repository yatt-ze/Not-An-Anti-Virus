Run setup.sh from payload.zip
