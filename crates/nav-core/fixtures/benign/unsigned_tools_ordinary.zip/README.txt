Command-line tools built locally; not signed.
